package com.example.roomapi.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.roomapi.model.BodyItem
import com.example.roomapi.model.UserModel

@Dao
interface RoomDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBodyItem(bodyitem: List<BodyItem?>?)
    //suspend fun insertBodyItem(bodyitem: List<BodyItem>)

    @Query("SELECT * FROM bodyitems")
    suspend fun getBodyItem() : List<BodyItem>
    //suspend fun getBodyItem() : List<BodyItem>
}