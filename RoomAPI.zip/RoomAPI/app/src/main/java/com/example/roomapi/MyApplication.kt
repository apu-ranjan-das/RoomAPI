package com.example.roomapi

import android.app.Application
import com.example.roomapi.api.ApiInterface
import com.example.roomapi.api.ApiUtilities
import com.example.roomapi.repository.BodyItemRepository
import com.example.roomapi.room.BodyItemDatabase

class MyApplication : Application(){

    lateinit var bodyitemRepository: BodyItemRepository
    override fun onCreate() {
        super.onCreate()

        val apiInterface = ApiUtilities.getInstance().create(ApiInterface::class.java)

        val database = BodyItemDatabase.getDatabase(applicationContext)

        bodyitemRepository = BodyItemRepository(apiInterface, database, applicationContext)


    }

}