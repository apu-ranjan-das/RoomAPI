package com.example.roomapi.model

import com.google.gson.annotations.SerializedName

data class UserModel(

	@field:SerializedName("msg")
	val msg: String? = null,

	@field:SerializedName("body")
	val body: List<BodyItem?>? = null,

	@field:SerializedName("statusCode")
	val statusCode: Int? = null
)

data class BodyItem(

	@field:SerializedName("app_mode_id")
	val appModeId: String? = null,

	@field:SerializedName("app_type")
	val appType: String? = null,

	@field:SerializedName("device_id")
	val deviceId: String? = null,

	@field:SerializedName("tag_name")
	val tagName: String? = null,

	@field:SerializedName("device_brand_name")
	val deviceBrandName: String? = null,

	@field:SerializedName("ip")
	val ip: String? = null,

	@field:SerializedName("app_mode")
	val appMode: String? = null,

	@field:SerializedName("_id")
	val id: String? = null,

	@field:SerializedName("rid")
	val rid: String? = null
)
