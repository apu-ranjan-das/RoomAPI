package com.example.roomapi.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.roomapi.api.ApiInterface
import com.example.roomapi.model.BodyItem

class BodyItemRepository(private val apiInterface: ApiInterface) {

    private val bodyitemLiveData = MutableLiveData<BodyItem>()

    val bodyitem : LiveData<BodyItem>
        get() = bodyitemLiveData

    suspend fun getBodyItem(){
        val result = apiInterface.getUserModel()


        if (result.body()!=null){
            bodyitemLiveData.postValue(result.body())
        }
    }
}