package com.example.roomapi

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.example.roomapi.api.ApiInterface
import com.example.roomapi.api.ApiUtilities
import com.example.roomapi.repository.BodyItemRepository
import com.example.roomapi.viewmodel.BodyItemViewModel
import com.example.roomapi.viewmodel.BodyItemViewModelFactory

class MainActivity : AppCompatActivity() {
    private lateinit var bodyItemViewModel: BodyItemViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val apiInterface = ApiUtilities.getInstance().create(ApiInterface::class.java)

        val bodyItemRepository = BodyItemRepository(apiInterface)

        bodyItemViewModel = ViewModelProvider(this, BodyItemViewModelFactory(bodyItemRepository)).get(BodyItemViewModel::class.java)

        bodyItemViewModel.bodyitem.observe(this, {

            Log.d("apidata", "onCreate: ${it.toString()}")


//            it.appMode.iterator().forEach {
//                Log.d("apidata", "appMode: ${it.a}")
//            }

        })

    }
}